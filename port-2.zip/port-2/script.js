// Handle navigation links with smooth redirect
document.querySelectorAll('.nav-hex a').forEach(link => {
  link.addEventListener('click', (e) => {
      e.preventDefault();
      const href = link.getAttribute('href');
      if (href) {
          if (href.startsWith('#')) {
              document.querySelector(href).scrollIntoView({ behavior: 'smooth' });
          } else {
              window.location.href = href;
          }
          createClickEffect(e);
      }
  });
});

// Make all collapsible sections expanded by default
document.querySelectorAll('.collapsible-content').forEach(content => {
  content.classList.add('show');
});

// Add click event to toggle collapsible sections
document.querySelectorAll('.code-block .key').forEach(key => {
  key.addEventListener('click', (e) => {
      const content = key.nextElementSibling;
      if (content && content.classList.contains('collapsible-content')) {
          content.classList.toggle('show');
      }
      createClickEffect(e);
  });
});

// Custom Cursor
let cursor = document.createElement('div');
cursor.className = 'custom-cursor';
document.body.appendChild(cursor);

document.addEventListener('mousemove', (e) => {
  cursor.style.left = e.clientX + 'px';
  cursor.style.top = e.clientY + 'px';
});

document.querySelectorAll('a, .key, .cta-button, .download-cv').forEach(element => {
  element.addEventListener('mouseover', () => {
      cursor.style.transform = 'scale(1.5)';
      cursor.style.boxShadow = '0 0 25px #00ffff, 0 0 50px #ff00ff';
  });
  element.addEventListener('mouseout', () => {
      cursor.style.transform = 'scale(1)';
      cursor.style.boxShadow = '0 0 15px #00ffff, 0 0 30px #00ccff';
  });
});

// Click Effect
function createClickEffect(e) {
  const effect = document.createElement('div');
  effect.className = 'click-effect';
  effect.style.left = e.clientX + 'px';
  effect.style.top = e.clientY + 'px';
  document.body.appendChild(effect);
  effect.addEventListener('animationend', () => effect.remove());
}

// Particle Animation
const canvas = document.getElementById('particle-canvas');
const ctx = canvas.getContext('2d');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const particlesArray = [];
const numberOfParticles = 100;

class Particle {
  constructor() {
      this.x = Math.random() * canvas.width;
      this.y = Math.random() * canvas.height;
      this.size = Math.random() * 3 + 1;
      this.speedX = Math.random() * 2 - 1;
      this.speedY = Math.random() * 2 - 1;
      this.color = `hsl(${Math.random() * 360}, 100%, 50%)`;
  }
  update() {
      this.x += this.speedX;
      this.y += this.speedY;
      if (this.x < 0 || this.x > canvas.width) this.speedX = -this.speedX;
      if (this.y < 0 || this.y > canvas.height) this.speedY = -this.speedY;
  }
  draw() {
      ctx.fillStyle = this.color;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
      ctx.fill();
  }
}

function init() {
  for (let i = 0; i < numberOfParticles; i++) {
      particlesArray.push(new Particle());
  }
}

function animate() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (let i = 0; i < particlesArray.length; i++) {
      particlesArray[i].update();
      particlesArray[i].draw();
  }
  requestAnimationFrame(animate);
}

init();
animate();

window.addEventListener('resize', () => {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
});

// Prevent default context menu
document.addEventListener('contextmenu', (e) => e.preventDefault());